create proc q4
as
begin 
select * from NHANVIEN where MA_NQL is null
end